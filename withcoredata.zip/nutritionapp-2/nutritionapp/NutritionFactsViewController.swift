//
//  NutritionFactsViewController.swift
//  nutritionapp
//
//  Created by Yun, Yeji on 5/3/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
import CoreData

class NutritionFactsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {


    @IBOutlet weak var serving: UITextField!
    @IBOutlet weak var measurementLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    var passedValue:Any = (Any).self
    let nutrient_names = ["Calories (kCal)", "Carbs (g)", "       Fiber (g)", "       Sugar (g)", "Protein (g)", "Fat (g)"]
    var nutrient_values: [Float] = [0,0,0,0,0,0]
    var loggedfood: [NSManagedObject] = []
    var amount:Float = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        var foodobj = (passedValue as! Food)
        nameLabel.text = foodobj.name
        infoLabel.text = foodobj.info
        let group = DispatchGroup()
        group.enter()
        let dataSession = FoodData(group:group)
        DispatchQueue.main.async {
            dataSession.reportData(withNumber: foodobj.number)
        }
        
        group.notify(queue: .main) {
            foodobj.nutrients = dataSession.nutri
            self.measurementLabel.text = "Per " + foodobj.nutrients.measurement
            self.nutrient_values = [Float(foodobj.nutrients.calories), Float(foodobj.nutrients.carbs), Float(foodobj.nutrients.fiber), Float(foodobj.nutrients.sugar), Float(foodobj.nutrients.protein), Float(foodobj.nutrients.fat)]
            self.passedValue = foodobj
            self.tableView.reloadData()
        }
        

        // Do any additional setup after loading the view.
    }

    @IBAction func addButton(_ sender: UIBarButtonItem) {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        // 1
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        // 2
        let entity =
            NSEntityDescription.entity(forEntityName: "FoodLogged",
                                       in: managedContext)!
        
        let foodlogged = NSManagedObject(entity: entity,
                                         insertInto: managedContext)
        foodlogged.setValue(nutrient_values[0], forKeyPath: "calories")
        foodlogged.setValue(nutrient_values[1], forKeyPath: "carbs")
        foodlogged.setValue(nutrient_values[2], forKeyPath: "fiber")
        foodlogged.setValue(nutrient_values[3], forKeyPath: "sugar")
        foodlogged.setValue(nutrient_values[4], forKeyPath: "protein")
        foodlogged.setValue(nutrient_values[5], forKeyPath: "fat")
        foodlogged.setValue("100g", forKeyPath: "measurements")
        foodlogged.setValue(self.amount, forKeyPath: "amount")
        foodlogged.setValue(nameLabel.text!, forKeyPath: "name")
        foodlogged.setValue(infoLabel.text!, forKeyPath: "info")
        foodlogged.setValue(Date(), forKeyPath: "date")
        
        do {
            try managedContext.save()
            loggedfood.append(foodlogged)
            print(loggedfood)
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nutrient_names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! NutritionTableViewCell
        var foodobj = (passedValue as! Food)
        cell.nutrientLabel.text = nutrient_names[indexPath.row]
        cell.valueLabel.text = "\(nutrient_values[indexPath.row])"
        return cell
    }
    
    @IBAction func servingTextField(_ sender: UITextField) {
        var input = serving.text!
        var foodobj = (passedValue as! Food)
        let values = [Float(foodobj.nutrients.calories), Float(foodobj.nutrients.carbs), Float(foodobj.nutrients.fiber), Float(foodobj.nutrients.sugar), Float(foodobj.nutrients.protein), Float(foodobj.nutrients.fat)]
        if input == "" {
            input = "1"
        }
        if input == "."{
            input = "0."
        }
        if Float(input) == nil {
            return
        }
        if let serving:Float = Float(input)!{
            for i in 0...nutrient_values.count-1 {
                nutrient_values[i] = values[i]*serving
                self.amount = serving
            }
            tableView.reloadData()

        }
    }
        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


