//
//  DailyNutritionViewController.swift
//  nutritionapp
//
//  Created by Yun, Yeji on 5/6/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
import CoreData

class DailyNutritionViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var serving: UITextField!
    @IBOutlet weak var measurementLabel: UILabel!
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    var passedValue:[NSManagedObject] = []
    let nutrient_names = ["Calories (kCal)", "Carbs (g)", "       Fiber (g)", "       Sugar (g)", "Protein (g)", "Fat (g)"]
    let nutrient_keys = ["calories", "carbs", "fiber", "sugar", "protein", "fat"]
    var nutrient_values: [Float] = []
    var amount:Float = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let foodobj = passedValue[0]
        for n in nutrient_keys {
            nutrient_values.append(foodobj.value(forKey: n)! as! Float)
        }
        nameLabel.text = foodobj.value(forKeyPath: "name") as? String
        infoLabel.text = foodobj.value(forKeyPath: "info") as? String
        measurementLabel.text = foodobj.value(forKeyPath: "measurements") as? String
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nutrient_names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! NutritionTableViewCell
        var foodobj = passedValue[0]
        cell.nutrientLabel.text = nutrient_names[indexPath.row]
        cell.valueLabel.text = "\(nutrient_values[indexPath.row])"
        //cell.valueLabel.text = "\(foodobj.value(forKey: nutrient_keys[indexPath.row])!)"
        return cell
    }
    
    @IBAction func servingTextField(_ sender: UITextField) {
        var input = serving.text!
        let foodobj = passedValue[0]
        if input == "" {
            input = "1"
        }
        if input == "."{
            input = "0."
        }
        if Float(input) == nil {
            return
        }
        if let serving:Float = Float(input)!{
            for i in 0...nutrient_values.count-1 {
                let value = foodobj.value(forKey: nutrient_keys[i]) as! Float
                nutrient_values[i] = value * serving
                self.amount = serving
            }
            tableView.reloadData()
            
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
