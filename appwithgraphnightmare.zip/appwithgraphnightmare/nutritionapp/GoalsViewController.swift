//
//  GoalsViewController.swift
//  nutritionapp
//
//  Created by Anna-Maria Andreeva on 4/26/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
import CoreData

class GoalsViewController: UIViewController {
    
    @IBOutlet weak var graphView: GraphView!
    @IBOutlet weak var waterView: WaterView!
    @IBOutlet weak var averageWaterDrunk: UILabel!
    @IBOutlet weak var maxLabel: UILabel!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var calorieGoal: UITextField!
    @IBOutlet weak var waterGoal: UITextField!
    var allgoals: [NSManagedObject] = []
    var goalsset: [NSManagedObject] = []
    var waterConsumed = 0
    
    override func viewWillAppear (_ animated: Bool) {
        super.viewWillAppear(animated)
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Goals")
        
        do {
            goalsset = try managedContext.fetch(fetchRequest)
            let count = goalsset.count
            if count != 0 {
                let goal = goalsset[count-1]
                
                if goal.value(forKeyPath: "waterconsumed") != nil {
                    waterConsumed = goal.value(forKeyPath: "waterconsumed") as! Int
                }
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo))")
        }
    }
    
    func setupGraphDisplay() {
        
        let maxDayIndex = stackView.arrangedSubviews.count - 1
        
        //  1 - replace last day with today's actual data
        graphView.graphPoints[graphView.graphPoints.count - 1] = waterConsumed
        //2 - indicate that the graph needs to be redrawn
        graphView.setNeedsDisplay()
        maxLabel.text = "\(graphView.graphPoints.max()!)"
        
        //  3 - calculate average from graphPoints
        let average = graphView.graphPoints.reduce(0, +) / graphView.graphPoints.count
        averageWaterDrunk.text = "\(average)"
        
        // 4 - setup date formatter and calendar
        let today = Date()
        let calendar = Calendar.current
        
        let formatter = DateFormatter()
        formatter.setLocalizedDateFormatFromTemplate("EEEEE")
        
        // 5 - set up the day name labels with correct days
        for i in 0...maxDayIndex {
            if let date = calendar.date(byAdding: .day, value: -i, to: today),
                let label = stackView.arrangedSubviews[maxDayIndex - i] as? UILabel {
                label.text = formatter.string(from: date)
            }
        }
    }
    
    
    @IBAction func saveButton(_ sender: UIButton) {
        if calorieGoal.text != nil && waterGoal.text != nil {
            let calories = (calorieGoal.text! as NSString).integerValue
            let waters = (waterGoal.text! as NSString).integerValue
            guard let appDelegate =
                UIApplication.shared.delegate as? AppDelegate else {
                    return
            }
            print ("save button")
            // 1
            let managedContext =
                appDelegate.persistentContainer.viewContext
            print ("managecontext")
            
            // 2
            let entity =
                NSEntityDescription.entity(forEntityName: "Goals",
                                           in: managedContext)!
            
            let goalsset = NSManagedObject(entity: entity,
                                           insertInto: managedContext)
            goalsset.setValue(calories, forKeyPath: "caloriegoals")
            goalsset.setValue(waters, forKeyPath: "watergoals")
            
            do {
                try managedContext.save()
                allgoals.append(goalsset)
                print(allgoals)
                let alert = UIAlertView()
                alert.title = "Saved"
                alert.addButton(withTitle: "OK")
                alert.show()
                
            }
            catch
                let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
            }
            
        }
        else{
            let alert = UIAlertView()
            alert.title = "Error, please insert numbers"
            alert.show()
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupGraphDisplay()
        
    }
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}



