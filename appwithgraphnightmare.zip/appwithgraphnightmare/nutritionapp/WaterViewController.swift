//
//  WaterViewController.swift
//  nutritionapp
//
//  Created by Minguell, Tomas P on 4/26/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
import CoreData

class WaterViewController: UIViewController {
    
    //Outlets
    @IBOutlet weak var waterView: WaterView!
    @IBOutlet weak var waterConsumption: UITextField!
    
    var goals: [NSManagedObject] = []
    
    var waterConsumed:Int =  0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func pushButtonPressed(_ button: WaterButton) {
        if button.isAddButton || self.waterConsumption.text != nil {
            
            waterConsumed = Int(self.waterConsumption.text!)!
            print(waterConsumed)
            
            waterView.counter += waterConsumed
            print(waterView.counter)
            
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                return
            }
            
            let managedContext =
                appDelegate.persistentContainer.viewContext
            print ("managecontext")
            let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Goals")
            let entity =
                NSEntityDescription.entity(forEntityName: "Goals",
                                           in: managedContext)!
            let goalsset = NSManagedObject(entity: entity,
                                           insertInto: managedContext)
           goalsset.setValue(waterView.counter, forKey: "waterconsumed")
            
            do {
                try managedContext.save()
                goals.append(goalsset)
            } catch let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
                }
            }
        print(goals)
        }
    }

