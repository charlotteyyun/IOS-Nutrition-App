//
//  ViewController.swift
//  nutritionapp
//
//  Created by Yun, Yeji on 4/22/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
let food = "burger"
let number = "45002204"
class ViewController: UIViewController {
    
    var dataSession = FoodData()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func checkFood(_ sender: UIButton) {
        print("hi")
        self.dataSession.searchData(withSearch: food)
        self.dataSession.reportData(withNumber: number)
    }
    

}

