//
//  FoodTrackerViewController.swift
//  nutritionapp
//
//  Created by Minguell, Tomas P on 4/22/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
//let foosd = "burger"
class FoodTrackerViewController: UIViewController {

//    var dataSession = FoodData()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    //MARK: Actions
  
//    @IBAction func checkFood(_ sender: UIButton) {
//        print("hi")
//        self.dataSession.searchData(withSearch: food)
//
//    }
    
}
