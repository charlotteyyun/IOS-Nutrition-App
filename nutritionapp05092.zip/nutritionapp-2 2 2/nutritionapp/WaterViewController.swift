//
//  WaterViewController.swift
//  nutritionapp
//
//  Created by Minguell, Tomas P on 4/26/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit

class WaterViewController: UIViewController {
    
    //Outlets
    @IBOutlet weak var waterView: WaterView!
    @IBOutlet weak var waterConsumption: UITextField!
    
    var waterConsumed:Int =  0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func pushButtonPressed(_ button: WaterButton) {
        if button.isAddButton && waterConsumption.text != nil && Int(waterConsumption.text!) != nil {
            
            waterConsumed = (waterConsumption.text! as NSString).integerValue
            print(waterConsumed)
            waterView.counter += waterConsumed
            print(waterView.counter)
        }
        else{
            return
        }
    }
}
