//
//  WaterViewController.swift
//  nutritionapp
//
//  Created by Minguell, Tomas P on 4/26/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
import CoreData

class WaterViewController: UIViewController {
    
    //Outlets
    @IBOutlet weak var goalLabel: UILabel!
    @IBOutlet weak var consumedLabel: UILabel!
    @IBOutlet weak var remainingLabel: UILabel!
    @IBOutlet weak var waterView: WaterView!
    @IBOutlet weak var waterConsumption: UITextField!
    @IBOutlet weak var textField: UITextField!
    var datePicker: UIDatePicker!
    var goalsset: [NSManagedObject] = []
    var waterlogged: [NSManagedObject] = []
    var waterConsumed:Float =  0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let date = Date()
        let format = DateFormatter()
        format.dateFormat = "MM/dd/yyyy"
        let formattedDate = format.string(from: date)
        textField.insertText(String(describing: formattedDate))
        datePicker = UIDatePicker()
        datePicker?.datePickerMode = .date
        datePicker?.addTarget(self, action: #selector(WaterViewController.dateChanged(datePicker:)), for: .valueChanged)
        
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(cancelDatePicker));
        
        toolbar.setItems([doneButton], animated: false)
        
        textField.inputAccessoryView = toolbar
        textField.inputView = datePicker
        goalLabel.text = "0"
        consumedLabel.text = "0"
        remainingLabel.text = "0"
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getGoal()
    }
    func getGoal(){
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate
            else {
                return
        }
        let managedContext =
            appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSManagedObject>(entityName: "WaterLogged")
        let otherRequest = NSFetchRequest<NSManagedObject>(entityName: "Goals")
        request.predicate = NSPredicate(format: "date == %@", textField.text!)
        do {
            goalsset = try managedContext.fetch(otherRequest)
            waterlogged = try managedContext.fetch(request)
            if waterlogged.count == 0{
                let entity =
                    NSEntityDescription.entity(forEntityName: "WaterLogged",
                                               in: managedContext)!
                
                let goal = NSManagedObject(entity: entity,
                                           insertInto: managedContext)
                goal.setValue(0, forKeyPath: "water")
                goal.setValue(textField.text!, forKeyPath: "date")
                do {
                    try managedContext.save()
                    waterlogged.append(goal)
                    
                }
                catch
                    let error as NSError {
                        print("Could not save. \(error), \(error.userInfo)")
                }
            }
            waterConsumed = waterlogged[0].value(forKey: "water") as! Float
            consumedLabel.text = "\(Int(round(waterConsumed)))"
            let count = goalsset.count
            if count == 0 {
                let entity =
                    NSEntityDescription.entity(forEntityName: "Goals",
                                               in: managedContext)!
                
                let goal = NSManagedObject(entity: entity,
                                           insertInto: managedContext)
                goal.setValue(0, forKeyPath: "caloriegoals")
                goal.setValue(0, forKeyPath: "watergoals")
                goal.setValue(0, forKeyPath: "carbgoals")
                goal.setValue(0, forKeyPath: "protgoals")
                goal.setValue(0, forKeyPath: "fatgoals")
                do {
                    try managedContext.save()
                    goalsset.append(goal)
                    
                }
                catch
                    let error as NSError {
                        print("Could not save. \(error), \(error.userInfo)")
                }
            }
            print(goalsset)
            let entityobj = goalsset[0]
            goalLabel.text = "\(Int(round(entityobj.value(forKeyPath: "watergoals") as! Float)))"
            waterView.water = (entityobj.value(forKeyPath: "watergoals")) as! Float
            waterView.counter = waterConsumed
            remainingLabel.text = "\(Int(round(entityobj.value(forKeyPath: "watergoals") as! Float)) - Int(round(waterConsumed)))"
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    @IBAction func pushButtonPressed(_ button: WaterButton) {
        if button.isAddButton && waterConsumption.text != nil && Int(waterConsumption.text!) != nil {
            guard let appDelegate =
                UIApplication.shared.delegate as? AppDelegate
                else {
                    return
            }
            let managedContext =
                appDelegate.persistentContainer.viewContext
            let entityobj = waterlogged[0]
            waterConsumed += (waterConsumption.text! as NSString).floatValue
            if waterConsumed < 0 {
                waterConsumed = 0
            }
            entityobj.setValue(waterConsumed, forKey: "water")
            do {
                try managedContext.save()
                waterlogged[0] = entityobj
                
            }
            catch
                let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
            }
            viewWillAppear(true)

            
        }
        else{
            return
        }
    }
    @objc func cancelDatePicker(){
        viewWillAppear(true)
        self.view.endEditing(true)
        textField.resignFirstResponder()
    }
    @objc func dateChanged(datePicker: UIDatePicker){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        textField.text = dateFormatter.string(from:datePicker.date)

        
    }
}
