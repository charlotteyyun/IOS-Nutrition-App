//
//  ViewController.swift
//  nutritionapp
//
//  Created by Yun, Yeji on 4/22/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
 

    var foodlogged: [NSManagedObject] = []
    var goalsset: [NSManagedObject] = []

    @IBOutlet weak var dashboardTable: UITableView!
    @IBOutlet weak var waterLabel: UILabel!
    @IBOutlet weak var calorieLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
    

        // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        //2
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "FoodLogged")
        let otherRequest = NSFetchRequest<NSManagedObject>(entityName: "Goals")
        
        
        //3
        do {
            foodlogged = try managedContext.fetch(fetchRequest)
            goalsset = try managedContext.fetch(otherRequest)
            self.dashboardTable.reloadData()
            let count = goalsset.count
            if count != 0 {
                let goal = goalsset[count-1]
            
                if goal.value(forKeyPath: "caloriegoals") != nil{
                
                    print("here", goal)
                    let water = goal.value(forKeyPath: "watergoals")
                    let input = goal.value(forKeyPath: "caloriegoals")
                
                    calorieLabel.text = "\(input!)"
                    waterLabel.text = "\(water!)"
                    //                calorieLabel.text = "2000"
                }
                else{
                    calorieLabel.text = "0"
                }
            }
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    
//    //MARK: table view source
//    func numberOfSections(in tableView: UITableView) -> Int {
//        //to add times?
//        return 1
//    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return foodlogged.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! DashboardTableViewCell
        
    //take data
        let food = foodlogged[indexPath.row]
        cell.foodName.text = food.value(forKeyPath: "name") as? String
        cell.foodDescript.text = food.value(forKeyPath: "info") as? String
        cell.calorieValue.text = String(describing: food.value(forKeyPath: "calories")!)
        return cell
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            guard let appDelegate =
                UIApplication.shared.delegate as? AppDelegate else {
                    return
            }
            
            let managedContext =
                appDelegate.persistentContainer.viewContext
            do {
                managedContext.delete(foodlogged[indexPath.row])
                try managedContext.save()
            } catch let error as NSError {
                print("Could not delete. \(error), \(error.userInfo)")
            }
            
            foodlogged.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)

        }
}
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDailyNutrition" {
            if segue.destination.isKind(of: DailyNutritionViewController.self) {
                let secondVC = segue.destination as! DailyNutritionViewController
                let index = dashboardTable.indexPathForSelectedRow?.row
                secondVC.passedValue = [self.foodlogged[index!]]
            }
        }

}
    
    //MARK: table view delegate
//    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
//        let edit = editAction(at: indexPath)
//        return UISwipeActionsConfiguration(actions: [edit])
//    }
//
//    func editAction (at IndexPath: IndexPath) -> UIContextualAction {
//        let action = UIContextualAction(style: .destructive, title: "Edit") { (action, view, completion) in
//            print("edit tried")
//            //delete from core data
//            //segue
//            completion(true)
//        }
//        action.image = #imageLiteral(resourceName: "editicon")
//        action.backgroundColor = .purple
//        return action
//    }
//    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
//        let delete = deleteAction(at: indexPath)
//
//        return UISwipeActionsConfiguration(actions: [delete])
//    }
//
//    func deleteAction(at IndexPath: IndexPath) -> UIContextualAction {
//        let action = UIContextualAction(style: .destructive, title: "Delete") { (action, view, completion) in
//            print("delete tried")
//        //delete from core data
//        self.dashboardTable.deleteRows(at: [IndexPath], with: .automatic)
//            completion(true)
//    }
//        action.image = #imageLiteral(resourceName: "trash")
//        action.backgroundColor = .red
//        return action
//    }
//
//
//
//}

}
