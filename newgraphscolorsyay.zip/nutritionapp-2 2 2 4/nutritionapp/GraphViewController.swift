//
//  GraphViewController.swift
//  nutritionapp
//
//  Created by Minguell, Tomas P on 5/9/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
import CoreData

class GraphViewController: UIViewController {

    @IBOutlet weak var graphView: GraphView!
    @IBOutlet weak var averageWaterDrunk: UILabel!
    @IBOutlet weak var maxLabel: UILabel!
    @IBOutlet weak var stackView: UIStackView!
    var goalsset: [NSManagedObject] = []
    var waterConsumed: Int = 10
    var waterGoal: Int = 50
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Goals")
        
        do {
            goalsset = try managedContext.fetch(fetchRequest)
            let count = goalsset.count
            if count != 0 {
                let goal = goalsset[count-1]
                
                if goal.value(forKeyPath: "waterconsumed") != nil {
                    waterConsumed = goal.value(forKeyPath: "waterconsumed") as! Int
                }
                if goal.value(forKeyPath: "watergoals") != nil {
                    waterGoal = goal.value(forKeyPath: "watergoals") as! Int
                }
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo))")
        }
        setupGraphDisplay()
    }
    
    func setupGraphDisplay() {
        let maxDayIndex = stackView.arrangedSubviews.count - 1
        
        print(graphView.consumedPoints)
        print(waterConsumed)
        graphView.consumedPoints[graphView.consumedPoints.count - 1] = waterConsumed
        graphView.goalPoints[graphView.goalPoints.count - 1] = waterGoal
        graphView.setNeedsDisplay()
        maxLabel.text = "\(graphView.goalPoints.max()!)"
        
        let average = graphView.consumedPoints.reduce(0, +) / graphView.consumedPoints.count
        averageWaterDrunk.text = "\(average)"
        
        let today = Date()
        let calendar = Calendar.current
        
        let formatter = DateFormatter()
        formatter.setLocalizedDateFormatFromTemplate("EEEEE")
        
        for i in 0...maxDayIndex {
            if let date = calendar.date(byAdding: .day, value: -i, to: today),
                let label = stackView.arrangedSubviews[maxDayIndex - i] as? UILabel {
                label.text = formatter.string(from: date)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    

        // Do any additional setup after loading the view.
    }
}
