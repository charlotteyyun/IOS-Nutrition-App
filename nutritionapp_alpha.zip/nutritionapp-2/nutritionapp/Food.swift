//
//  Food.swift
//  nutritionapp
//
//  Created by Yun, Yeji on 4/27/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import Foundation

struct Food{
    var name:String
    var info:String
    var calorie: Int
}
