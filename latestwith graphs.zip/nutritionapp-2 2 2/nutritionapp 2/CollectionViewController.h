//
//  CollectionViewController.h
//  nutritionapp
//
//  Created by Yun, Yeji on 5/1/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionViewController : UICollectionViewController

@end
