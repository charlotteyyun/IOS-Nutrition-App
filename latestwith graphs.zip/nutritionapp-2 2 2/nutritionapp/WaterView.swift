//
//  WaterView.swift
//  nutritionapp
//
//  Created by Minguell, Tomas P on 4/26/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit


@IBDesignable class WaterView: UIView {
    
    var water: Float = 0
    
    
    
    private struct Constants {
        //We will change this to equal the water goal that the user enters
        static let lineWidth: CGFloat = 5.0
        static let arcWidth: CGFloat = 5
        
        static var halfOfLineWidth: CGFloat {
            return lineWidth / 2
        }
    }
    
    @IBInspectable var counter: Float = 0 {
        didSet {
            //            if counter <= water {
            //                //the view needs to be refreshed
            setNeedsDisplay()
            
        }
    }
    @IBInspectable var sineLineColor: UIColor = UIColor.blue
    @IBInspectable var glassColor: UIColor = UIColor.gray
    @IBInspectable var fillColor: UIColor = UIColor.green
    
    override func draw(_ rect: CGRect) {
        
        let width = self.frame.size.width - 10
        let height = self.frame.size.height - 10
        //        let sineWidth = acos(((height - 5) * CGFloat(Double.pi))/30)
        //        print (sineWidth)
        //        let newWidth = tan(sineWidth)*(height-5)
        //        print (newWidth)
        let center = CGPoint(x: (width+6)/2, y: height-173)
        
        var sineOrigin = CGPoint(x: (width-30) * 0.2, y: (height-13))
        if water > 0 {
            //have to change y
            sineOrigin = CGPoint(x: (width-30) * 0.2, y: ((height - (CGFloat(counter/water) * height)))-13)
            
        }
        
        
        
        if counter > 0 && water > 0 {
            let sinePath = UIBezierPath()
            sinePath.move(to: sineOrigin)
            
            for angle in stride(from: 5.0, through: 360.0, by: 5.0) {
                // have to change width
                let x = sineOrigin.x + CGFloat(angle/360.0) * width * 0.7
                //curve of the line sine
                let y = sineOrigin.y - CGFloat(sin(angle/180.0 * Double.pi)) * height * 0.04
                sinePath.addLine(to: CGPoint(x: x, y: y))
            }
            sinePath.addLine(to: CGPoint(x: width-30, y: height-14))
            sinePath.addCurve(to: CGPoint(x:40.0, y: height-14), controlPoint1: CGPoint(x: (width+6)/2, y: height+18), controlPoint2: CGPoint(x: (width+6)/2, y: height+16))
            sinePath.close()
            
            fillColor.setFill()
            sinePath.fill()
            sineLineColor.setStroke()
            sinePath.stroke()
        }
        
        
        
        
        //        func addArc(withCenter center: CGPoint,
        //                    radius: CGFloat,
        //                    startAngle: CGFloat,
        //                    endAngle: CGFloat,
        //                    clockwise: Bool) { }
        
        let path = UIBezierPath()
        
        
        path.addArc(withCenter: center, radius: (width+120)/2, startAngle: CGFloat((2.62*Double.pi)/4), endAngle: CGFloat((1.345*Double.pi)/4), clockwise: false)
        path.addLine(to: CGPoint(x: width-30, y: 5.0))
        path.addLine(to: CGPoint(x:40.0, y: 5.0))
        path.close()
        fillColor.setFill()
        
        
        
        
        
        
        
        
        path.lineWidth = Constants.arcWidth
        glassColor.setStroke()
        path.stroke()
    }
}
