//
//  keyLabels.swift
//  nutritionapp
//
//  Created by Andreeva, Anna-maria K on 5/13/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit

@IBDesignable class keyLabels: UIView {
    
//    override func draw(_ rect: CGRect) {
//        let width = 10
//        let actual = UIBezierPath
//        actual.move(to)
//        let goal = UIBezierPath
//    }

}
