//
//  GoalsViewController.swift
//  nutritionapp
//
//  Created by Anna-Maria Andreeva on 4/26/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
import CoreData

class GoalsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var calorieGoal: UITextField!
    @IBOutlet weak var waterGoal: UITextField!
    var allgoals: [NSManagedObject] = []
    let nutrient_names = ["Calories (kCal)", "Carbs (g)", "       Fiber (g)", "       Sugar (g)", "Protein (g)", "Fat (g)"]
    @IBAction func saveButton(_ sender: UIButton) {
        if calorieGoal.text != nil && waterGoal.text != nil {
            let calories = (calorieGoal.text! as NSString).integerValue
            let waters = (waterGoal.text! as NSString).integerValue
            guard let appDelegate =
                UIApplication.shared.delegate as? AppDelegate else {
                    return
            }
            print ("save button")
            // 1
            let managedContext =
                appDelegate.persistentContainer.viewContext
            print ("managecontext")
            
            // 2
            let entity =
                NSEntityDescription.entity(forEntityName: "Goals",
                                           in: managedContext)!
            
            let goalsset = NSManagedObject(entity: entity,
                                           insertInto: managedContext)
            goalsset.setValue(calories, forKeyPath: "caloriegoals")
            goalsset.setValue(waters, forKeyPath: "watergoals")
            
            do {
                try managedContext.save()
                allgoals.append(goalsset)
                print(allgoals)
                let alert = UIAlertView()
                alert.title = "Saved"
                alert.addButton(withTitle: "OK")
                alert.show()
                
            }
            catch
                let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
            }
            
        }
        else{
            let alert = UIAlertView()
            alert.title = "Error, please insert numbers"
            alert.show()
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nutrient_names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! NutritionTableViewCell
        cell.nutrientLabel.text = nutrient_names[indexPath.row]
        cell.valueLabel.text = "0"
        return cell
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
