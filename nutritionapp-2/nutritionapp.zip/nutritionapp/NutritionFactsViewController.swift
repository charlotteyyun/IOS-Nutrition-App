//
//  NutritionFactsViewController.swift
//  nutritionappTests
//
//  Created by Yun, Yeji on 4/26/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit

class NutritionFactsViewController: UIViewController,UICollectionViewDelegate, UICollectionViewDataSource {

    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

