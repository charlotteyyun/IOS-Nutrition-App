//
//  WaterViewController.swift
//  nutritionapp
//
//  Created by Minguell, Tomas P on 4/26/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
import CoreData

class WaterViewController: UIViewController {
    
    //Outlets
    @IBOutlet weak var waterView: WaterView!
    @IBOutlet weak var waterConsumption: UITextField!
    var goalsset: [NSManagedObject] = []
    
    var waterConsumed:Float =  0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getGoal()
    }
    func getGoal(){
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate
            else {
                return
        }
        let managedContext =
            appDelegate.persistentContainer.viewContext
        let otherRequest = NSFetchRequest<NSManagedObject>(entityName: "Goals")
        do {
            goalsset = try managedContext.fetch(otherRequest)
            let count = goalsset.count
            if count != 0 {
                let goal = goalsset[count-1]
                if goal.value(forKeyPath: "watergoals") != nil{
                    print("here", goal)
                    let water = goal.value(forKeyPath: "watergoals") as! Float
                    print(water)
                    waterView.water = water
                    
                }
                else{
                    print("goalsnil")
                    return
                }
            }
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    @IBAction func pushButtonPressed(_ button: WaterButton) {
        if button.isAddButton && waterConsumption.text != nil && Int(waterConsumption.text!) != nil {
            
            waterConsumed = (waterConsumption.text! as NSString).floatValue
            print(waterConsumed)
            waterView.counter += waterConsumed
            print(waterView.counter)
        }
        else{
            return
        }
    }
}
