//
//  MyButton.swift
//  nutritionapp
//
//  Created by Yun, Yeji on 5/9/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit

class MyButton: UIButton {
    
    var myView = UIView()
    var toolBarView = UIView()
    
    override var inputView: UIView {
        get {
            return self.myView
        }
        
        set {
            self.myView = newValue
            self.becomeFirstResponder()
        }
    }
    
    override var inputAccessoryView: UIView {
        get {
            return self.toolBarView
        }
        set {
            self.toolBarView = newValue
        }
    }
    
    override var canBecomeFirstResponder: Bool {
        return true
    }
    
}
