//
//  GraphViewController.swift
//  nutritionapp
//
//  Created by Minguell, Tomas P on 5/9/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
import CoreData

class GraphViewController: UIViewController {
    
//    let calorieView: UIView!

    @IBOutlet weak var segments: UISegmentedControl!
    @IBOutlet weak var keyLabels: UIView!
    @IBAction func segmentControl(_ sender: Any) {
        
        let getIndex = segments.selectedSegmentIndex
        print(getIndex)
        switch (getIndex){
        case 0:
            typeLabel.text = "Water Consumed"
            setupWaterGraphDisplay()
            graphView.setNeedsDisplay()
        case 1:
            typeLabel.text = "Calories Consumed"
            setupCaloriesGraphDisplay()
            graphView.setNeedsDisplay()
        default:
            print("no select")
        }
    }
    
    @IBOutlet weak var unitLabel: UILabel!
    @IBOutlet weak var graphView: GraphView!
    @IBOutlet weak var averageWaterDrunk: UILabel!
    @IBOutlet weak var graphAverage: UILabel!
    @IBOutlet weak var maxLabel: UILabel!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var typeLabel: UILabel!
    var goalsset: [NSManagedObject] = []
    var calset: [NSManagedObject] = []
    var waterset: [NSManagedObject] = []
    var waterConsumed: Int = 10
    var waterGoal: Int = 50
    var caloriesConsumed: Int = 10
    var caloriesGoal: Int = 50
    var consumed: [Float] = [0,0,0,0,0,0]
    let nutrient_keys = ["calories", "carbs", "fiber", "sugar", "protein", "fat"]

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Goals")
        let caloriefetch = NSFetchRequest<NSManagedObject>(entityName: "FoodLogged")
        let waterfetch = NSFetchRequest<NSManagedObject>(entityName: "WaterLogged")
        
        do {
            goalsset = try managedContext.fetch(fetchRequest)
            calset = try managedContext.fetch(caloriefetch)
            waterset = try managedContext.fetch(waterfetch)
            let count = goalsset.count
            if count != 0 {
                let goal = goalsset[count-1]
                
                if goal.value(forKeyPath: "watergoals") != nil {
                    waterGoal = goal.value(forKeyPath: "watergoals") as! Int
                }
                
                if goal.value(forKeyPath: "caloriegoals") != nil {
                    caloriesGoal = goal.value(forKeyPath: "caloriegoals") as! Int
                }
            }
            
            let ccount = calset.count
            if ccount != 0 {
                consumed = [0,0,0,0,0,0]
                for food in calset {
                    
                    for index in 0...nutrient_keys.count-1 {
                        if food.value(forKeyPath: nutrient_keys[index]) != nil && food.value(forKeyPath: "amount") != nil {
                            consumed[index] += (food.value(forKeyPath: nutrient_keys[index]) as! Float)*(food.value(forKeyPath: "amount") as! Float)
                        }
                    }
                }
                caloriesConsumed = Int(round(consumed[0]))
            }
            let wcount = waterset.count
            if wcount != 0 {
                if waterset[count-1].value(forKeyPath: "water") != nil {
                    waterConsumed = waterset[count-1].value(forKeyPath: "water") as! Int
                }

                
            }
        }
        catch
            let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo))")
        }
        setupWaterGraphDisplay()
//        graphView.setNeedsDisplay()
    }
    
    func setupWaterGraphDisplay() {
        unitLabel.text = "ml"
        let maxDayIndex = stackView.arrangedSubviews.count - 1
        graphView.startColor = .init(red: 0.105, green: 0.733, blue: 1, alpha: 1)
        graphView.endColor = .init(red: 0.878, green: 0.984, blue: 1, alpha: 1)
        segments.tintColor = UIColor.init(red: 0.105, green: 0.733, blue: 1, alpha: 1)
        print(graphView.consumedPoints)
        print(waterConsumed)
        graphView.consumedPoints[graphView.consumedPoints.count - 1] = waterConsumed
        graphView.goalPoints[graphView.goalPoints.count - 1] = waterGoal
        graphView.setNeedsDisplay()
        maxLabel.text = "\(graphView.goalPoints.max()!)"
        
        let average = graphView.consumedPoints.reduce(0, +) / graphView.consumedPoints.count
        averageWaterDrunk.text = "\(average)"
        graphAverage.text = "\(average)"
        
        let today = Date()
        let calendar = Calendar.current
        
        let formatter = DateFormatter()
        formatter.setLocalizedDateFormatFromTemplate("EEEEE")
        
        for i in 0...maxDayIndex {
            if let date = calendar.date(byAdding: .day, value: -i, to: today),
                let label = stackView.arrangedSubviews[maxDayIndex - i] as? UILabel {
                label.text = formatter.string(from: date)
            }
        }
        graphView.setNeedsDisplay()
    }
    func setupCaloriesGraphDisplay() {
        unitLabel.text = "kcal"
        let maxDayIndex = stackView.arrangedSubviews.count - 1
        graphView.startColor = .init(red: 1, green: 0.682, blue: 0.255, alpha: 1)
        graphView.endColor = .init(red: 1, green: 0.92, blue: 0.86, alpha: 1)
        segments.tintColor = UIColor.init(red: 1, green: 0.682, blue: 0.255, alpha: 1)
        
        print(graphView.consumedPoints)
        print(caloriesConsumed)
        graphView.consumedPoints[graphView.consumedPoints.count - 1] = caloriesConsumed
        graphView.goalPoints[graphView.goalPoints.count - 1] = caloriesGoal
        graphView.setNeedsDisplay()
        maxLabel.text = "\(graphView.goalPoints.max()!)"
        
        let average = graphView.consumedPoints.reduce(0, +) / graphView.consumedPoints.count
        averageWaterDrunk.text = "\(average)"
        graphAverage.text = "\(average)"

        
        let today = Date()
        let calendar = Calendar.current
        
        let formatter = DateFormatter()
        formatter.setLocalizedDateFormatFromTemplate("EEEEE")
        
        for i in 0...maxDayIndex {
            if let date = calendar.date(byAdding: .day, value: -i, to: today),
                let label = stackView.arrangedSubviews[maxDayIndex - i] as? UILabel {
                label.text = formatter.string(from: date)
            }
        }
        graphView.setNeedsDisplay()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupWaterGraphDisplay()
//        graphView.setNeedsDisplay()
    

        // Do any additional setup after loading the view.
    }
    
    
}
