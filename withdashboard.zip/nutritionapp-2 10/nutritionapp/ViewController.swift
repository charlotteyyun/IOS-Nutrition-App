//
//  ViewController.swift
//  nutritionapp
//
//  Created by Yun, Yeji on 4/22/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
 

    @IBOutlet weak var dashboardTable: UITableView!
    @IBOutlet weak var waterLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        self.waterLabel.text = "No water drunk today!"

        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: table view source
    func numberOfSections(in tableView: UITableView) -> Int {
        //to add times?
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        <#code#>
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! DashboardTableViewCell
        
    //take data
        cell.foodName.text =
        cell.foodDescript.text =
        cell.calorieValue.text =
        return cell
    }
    
    //MARK: table view delegate
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let edit = editAction(at: indexPath)
        return UISwipeActionsConfiguration(actions: [edit])
    }
    func editAction (at IndexPath: IndexPath) -> UIContextualAction {
        let action = UIContextualAction(style: .destructive, title: "Edit") { (action, view, completion) in
            //delete from core data
            //segue
            completion(true)
        }
        action.image = #imageLiteral(resourceName: "editicon")
        action.backgroundColor = .purple
        return action
    }
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let delete = deleteAction(at: indexPath)
        
        return UISwipeActionsConfiguration(actions: [delete])
    }
    
    func deleteAction(at IndexPath: IndexPath) -> UIContextualAction {
        let action = UIContextualAction(style: .destructive, title: "Delete") { (action, view, completion) in
        //delete from core data
        self.dashboardTable.deleteRows(at: [IndexPath], with: .automatic)
            completion(true)
    }
        action.image = #imageLiteral(resourceName: "trash")
        action.backgroundColor = .red
        return action
    }
    
        
    
}

